insert into store_returns (select * from srv);
rollback;
